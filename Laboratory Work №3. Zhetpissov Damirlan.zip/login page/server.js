const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const users = [];

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/', (req, res) => {
    const sessionUser = req.cookies.session_user;
    if (!sessionUser) {
        return res.redirect('/login');
    }
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/user', (req, res) => {
    const sessionUser = req.cookies.session_user;
    if (!sessionUser) return res.status(401).json({ error: 'Unauthorized' });
    res.json({ username: sessionUser });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.redirect('/login?error=Заполните все поля!');

    const found = users.find(u => u.username === username && u.password === password);
    if (!found) return res.redirect('/login?error=Неверный логин или пароль!');

    res.cookie('session_user', username, { maxAge: 86400000, httpOnly: true });
    res.redirect('/');
});

app.post('/register', (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) return res.redirect('/register?error=Заполните все поля!');
    if (password.length < 6) return res.redirect('/register?error=Пароль должен быть от 6 символов!');
    if (users.some(u => u.username === username)) return res.redirect('/register?error=Такой пользователь уже существует!');

    users.push({ username, email, password });
    res.redirect('/login');
});

app.get('/logout', (req, res) => {
    res.clearCookie('session_user');
    res.redirect('/login');
});

app.listen(8080, () => {
    console.log('Сервер запущен: http://localhost:8080');
});